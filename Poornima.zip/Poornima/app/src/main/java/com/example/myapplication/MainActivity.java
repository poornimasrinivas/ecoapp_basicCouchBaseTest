package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.nfc.Tag;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.couchbase.lite.CouchbaseLite;
import com.couchbase.lite.CouchbaseLiteException;
import com.couchbase.lite.DataSource;
import com.couchbase.lite.Database;
import com.couchbase.lite.DatabaseConfiguration;
import com.couchbase.lite.Expression;
import com.couchbase.lite.MutableDocument;
import com.couchbase.lite.Query;
import com.couchbase.lite.QueryBuilder;
import com.couchbase.lite.ResultSet;
import com.couchbase.lite.SelectResult;

public class MainActivity extends AppCompatActivity {

    Button loginBtn;
    EditText uName,uPwd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        uName= findViewById(R.id.username);
        uPwd= findViewById(R.id.password);
        loginBtn=findViewById(R.id.loginButton);



        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                    //initialise
                    CouchbaseLite.init(getApplicationContext());
                    String sUserName=uName.getText().toString();
                    String sUserPassword=uPwd.getText().toString();
                    //create new db
                    DatabaseConfiguration dbConfig = new DatabaseConfiguration();
                    try {
                        Database db = new Database("ecoapp", dbConfig);
                        //create new record
                        MutableDocument mutableUserDocument=new MutableDocument();

                        Query query = QueryBuilder.select(SelectResult.all())
                                .from(DataSource.database(db))
                                .where(Expression.property("UserName").equalTo(Expression.string(sUserName)));
                        ResultSet result = query.execute();
                       // Log.i(TAG,"Number of rows ::  " + result.allResults().size());
                        if(result.allResults().size()==0){
                          //  Log.i(TAG, "new user registeration");
                            Toast.makeText(getApplicationContext(), "New user Registration...",Toast.LENGTH_LONG).show();
                            //Add record:
                            mutableUserDocument.setString("UserName",sUserName);
                            mutableUserDocument.setString("Password",sUserPassword);
                            // Save it to the database.
                            db.save(mutableUserDocument);
                        //    Intent intent=new Intent(Intent.ACTION_VIEW);
                           // startActivity(intent,R.layout.activity_profile_page);

                        }
                        else{
                         //   Log.i(TAG, " user exists");
                            Toast.makeText(getApplicationContext(), " Existing User...",Toast.LENGTH_LONG).show();


                        }

                        //Add record:
                        mutableUserDocument.setString("UserName",sUserName);

                        // Save it to the database.
                        db.save(mutableUserDocument);
                        // Update a document.
                        mutableUserDocument = db.getDocument(mutableUserDocument.getId()).toMutable();
                        mutableUserDocument.setString("language", "Java");

                    } catch (CouchbaseLiteException e) {
                        e.printStackTrace();
                    }

                } finally {

                }
            }
        });
    }
}
