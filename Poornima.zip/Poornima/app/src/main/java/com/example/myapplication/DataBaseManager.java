package com.example.myapplication;

import com.couchbase.lite.CouchbaseLite;

public class DataBaseManager {

    //initiaisation
   // CouchbaseLite.init(context);

}
